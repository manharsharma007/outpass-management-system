					<ul>
						<li><a href="<?= SITE_URL.'home/reports' ?>">Reports</a></li>
						<li><a href="<?= SITE_URL.'home/noncomer' ?>">Non Comers</a></li>
						<li><a href="<?= SITE_URL.'home/latecomer' ?>">Late Comers</a></li>
						<li><a href="<?= SITE_URL.'home/userhistory' ?>">User History</a></li>
					</ul>
				