				<ul>
						<li><a href="<?= SITE_URL.'home/' ?>">Dashboard</a></li>
						<li><a href="<?= SITE_URL.'home/issued' ?>">Issued Pass</a></li>
						<li><a href="<?= SITE_URL.'home/create_pass' ?>">Create Pass</a></li>
						<li><a href="<?= SITE_URL.'home/return' ?>">Return Pass</a></li>
						<li><a href="<?= SITE_URL.'admin/add_student' ?>">Add Users</a></li>
						<li><a href="<?= SITE_URL.'admin/view_students' ?>">View Users</a></li>
						<li><a href="<?= SITE_URL.'home/reports' ?>">Reports</a></li>
						<li><a href="<?= SITE_URL.'home/settings' ?>">Settings</a></li>
						<li><a href="<?= SITE_URL.'logout' ?>">Logout</a></li>
					</ul>