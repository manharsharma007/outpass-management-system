					<ul>
						<li><a href="<?= SITE_URL.'home/add_student' ?>">Add Student</a></li>
						<li><a href="<?= SITE_URL.'home/add_user' ?>">Add User</a></li>
					</ul>
				