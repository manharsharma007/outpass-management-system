<?php
/**
 * File contains necessary information that defines the controllers of your application
 * Source code pattern must not be modified
 * Files to be used with the comments.
 * @Author : Operce Technologies
 * @Year : 2016
 *
 *
 **/

defined('_DONUT') or die('Access Denied');

Loader::load('security',APP);

abstract class Model extends security {
	
	private function __constructor() {

	}
	private function __clone() {

	}

}

?>
