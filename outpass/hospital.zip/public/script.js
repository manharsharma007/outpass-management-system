$('.datepicker').appendDtpicker({
    "dateFormat": "YYYY-MM-DD",
    "dateOnly": true,
    "closeOnSelected": true,
    "autodateOnStart": false
    });

$('.datetimepicker').appendDtpicker({
    "dateFormat": "YYYY-MM-DD hh:mm",
    "closeOnSelected": true,
    "autodateOnStart": false
    });