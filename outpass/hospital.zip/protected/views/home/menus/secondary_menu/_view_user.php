					<ul>
						<li><a href="<?= SITE_URL.'home/view_students' ?>">View Student</a></li>
						<li><a href="<?= SITE_URL.'home/view_users' ?>">View User</a></li>
					</ul>