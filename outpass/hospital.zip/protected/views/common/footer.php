
</div>
		</div>


		<div class="row footer-info">
			<div class="row-fixed">
				<div class="row">
					<p>Designed By <a href="http://www.operce.com"><b>Operce Technologies Pvt. Ltd.</b></a></p>
				</div>
				<div class="absolute">
					<a href="http://www.operce.com"><img src="<?= SITE_URL ?>/public/images/logo_new.png" alt=""></a>
				</div>
			</div>
		</div>
	</div>
	<?php Loader::addScript('jquery.datetimepicker.js'); ?>
	<?php Loader::addScript('script.js'); ?>
</body>
</html>